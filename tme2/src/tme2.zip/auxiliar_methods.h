#include<string.h>
#include <stdlib.h>
#include <stdio.h>
char * newcopy(const char * src);

char * stringConcat(char * src1, char * src2);

int digitsInANumber(int i);

char * intToString(int i);
